NISHIY DEMON LIST — CLOUD SETUP (GitHub Pages + Firebase)

WHAT THIS PACKAGE DOES
- Visitors can send level/completion requests without signing in.
- Requests are stored centrally in Firestore and visible to admins.
- Admins sign in with Google; only allowlisted Google email accounts can approve/reject requests, add cloud levels, and change order among cloud-added levels.
- Approved records and cloud-added levels sync to visitors' pages.

IMPORTANT SECURITY CHOICE
A shared password placed inside a static HTML file is not secure: anyone can inspect the source and extract it. This version uses Google sign-in plus an administrator email allowlist enforced by Firestore Rules. You can use the same Google admin account among admins, but separate accounts are safer and allow audit trails.

SETUP
1. Open https://console.firebase.google.com/ and create a Firebase project.
2. In Project settings > General > Your apps, add a Web app and copy its Firebase config.
3. In Authentication > Sign-in method, enable Google. In Authentication > Settings > Authorized domains, add your GitHub Pages domain (e.g. YOURNAME.github.io).
4. In Firestore Database, create a database.
5. In the HTML file, find `const firebaseConfig = { ... }` and replace PASTE_FIREBASE_API_KEY, PASTE_PROJECT_ID and PASTE_FIREBASE_APP_ID with the values from Firebase. Keep authDomain in the form PROJECT_ID.firebaseapp.com unless Firebase shows a different value.
6. In the HTML file, replace `REPLACE_WITH_ADMIN_GOOGLE_EMAIL` in ADMIN_EMAILS with your Google account email. Add more emails separated by commas if needed.
7. In Firebase Console > Firestore > Rules, paste the contents of firestore.rules. Replace the placeholder email there with the same administrator email(s). Publish the rules.
8. Upload `Nishiy_Demon_List_Cloud_System.html` to your GitHub repository and rename it to `index.html` if it should be the main page. Commit and push; wait for GitHub Pages to deploy.
9. Open the deployed site and test: send a test request in a private/incognito window, sign in with an allowlisted Google account, approve it, and verify it appears to other visitors.

CURRENT LIMITATION
The existing list is embedded in the HTML. Cloud-added levels and approved records sync from Firestore, but the original embedded levels are not automatically copied to Firestore. After setup, sign in as an admin and press “Импортировать исходный лист” once. This copies the existing embedded levels into Firestore; the rank editor can then reorder the imported list collaboratively. New cloud levels and approved records sync from Firestore.

TROUBLESHOOTING
- `auth/unauthorized-domain`: add the exact GitHub Pages host under Firebase Authentication > Authorized domains.
- `Missing or insufficient permissions`: compare the admin email in the HTML and Firestore Rules exactly, then publish the rules.
- Do not put passwords, service-account keys, or private server keys into the HTML or GitHub repository.
